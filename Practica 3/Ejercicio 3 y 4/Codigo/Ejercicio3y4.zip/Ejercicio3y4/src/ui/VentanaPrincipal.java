package ui;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.border.MatteBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import logic.XMLReader;

import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class VentanaPrincipal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JButton btnExaminar;
	private JLabel lblBienvenido;
	private JPanel panel;
	private JLabel lblIntroducirFicheroxml;
	private JButton btnExaminar_1;
	private XMLReader xml;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal frame = new VentanaPrincipal();
					frame.setLocationRelativeTo(null);
					JOptionPane.showMessageDialog(null, "Este programa generar� ficheros con formato xml. La ubicaci�n de los ficheros generados es el escritorio");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/true-damage-ujawnienie-zwiastun.jpg")));
		setTitle("ObtainMetaRoute");
		setResizable(false);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 421, 296);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 51, 102));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblBienvenido());
		contentPane.add(getPanel());
	}

	private JButton getBtnExaminar() {
		if (btnExaminar == null) {
			btnExaminar = new JButton("Comenzar");
			btnExaminar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(xml!=null) {
						xml.execute();
						JOptionPane.showMessageDialog(null, "Archivos generados");
					}
					else
						JOptionPane.showMessageDialog(null, "No se ha seleccionado ning�n archivo XML");
				}
			});
			btnExaminar.setBackground(Color.LIGHT_GRAY);
			btnExaminar.setBounds(249, 117, 126, 23);
		}
		return btnExaminar;
	}

	private JLabel getLblBienvenido() {
		if (lblBienvenido == null) {
			lblBienvenido = new JLabel("Bienvenido a ObtainMetaRoute");
			lblBienvenido.setForeground(Color.WHITE);
			lblBienvenido.setBackground(Color.WHITE);
			lblBienvenido.setHorizontalAlignment(SwingConstants.CENTER);
			lblBienvenido.setFont(new Font("Britannic Bold", Font.PLAIN, 27));
			lblBienvenido.setBounds(10, 11, 385, 65);
		}
		return lblBienvenido;
	}

	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBackground(new Color(51, 153, 204));
			panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
			panel.setBounds(10, 80, 385, 166);
			panel.setLayout(null);
			panel.add(getBtnExaminar());
			panel.add(getLblIntroducirFicheroxml());
			panel.add(getBtnExaminar_1(this));
		}
		return panel;
	}

	private JLabel getLblIntroducirFicheroxml() {
		if (lblIntroducirFicheroxml == null) {
			lblIntroducirFicheroxml = new JLabel("Introducir fichero de rutas .XML");
			lblIntroducirFicheroxml.setFont(new Font("Tahoma", Font.PLAIN, 13));
			lblIntroducirFicheroxml.setBounds(10, 28, 183, 23);
		}
		return lblIntroducirFicheroxml;
	}

	private JButton getBtnExaminar_1(JFrame th) {
		if (btnExaminar_1 == null) {
			btnExaminar_1 = new JButton("Examinar");
			btnExaminar_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					 JFileChooser loadFile= new JFileChooser();
					 loadFile.setApproveButtonText("Select File");
					 loadFile.setAcceptAllFileFilterUsed(false);
					 FileNameExtensionFilter f1 = new FileNameExtensionFilter("XML Files", "xml");
					 loadFile.setFileFilter(f1);
					 loadFile.showOpenDialog(th);
					 File ruta = loadFile.getSelectedFile();
					 xml = new XMLReader(ruta);
				}
			});
			btnExaminar_1.setBackground(Color.LIGHT_GRAY);
			btnExaminar_1.setBounds(249, 28, 126, 24);
		}
		return btnExaminar_1;
	}
}
