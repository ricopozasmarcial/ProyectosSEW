package logic;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

public class XMLReader {

	private File file;
	private XMLWriter writer;

	public XMLReader(File file) {
		this.file = file;
	}

	public void execute() {

		try {
			File fXmlFile = this.file;
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("ruta");
			for (int i = 0; i < nList.getLength(); i++) {
				Node nNode = nList.item(i);
				String numero = "", tipo = "", transporte = "", duracion = "", agencia = "", lugar = "";
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					numero = "ruta-numero" + (i + 1);
					tipo = "Tipo de la ruta : " + eElement.getElementsByTagName("tipo").item(0).getTextContent();
					transporte = "Transporte recomendado : "
							+ eElement.getElementsByTagName("transporte").item(0).getTextContent();
					duracion = "Duracion de la : " + eElement.getElementsByTagName("duracion").item(0).getTextContent();
					agencia = "Agencia que gestiona : "
							+ eElement.getElementsByTagName("agencia").item(0).getTextContent();
					lugar = "Lugar donde se realizar� : "
							+ eElement.getElementsByTagName("lugar").item(0).getTextContent();
				}
				writer = new XMLWriter(numero, tipo, transporte, duracion, agencia, lugar);
				writer.execute();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
