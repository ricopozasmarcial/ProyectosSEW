package logic;

import java.io.File;

import javax.swing.filechooser.FileSystemView;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class XMLWriter {

	private String numero;
	private String tipo;
	private String transporte;
	private String duracion;
	private String agencia;
	private String lugar;

	public XMLWriter(String numero, String tipo, String transporte, String duracion, String agencia, String lugar) {
		this.numero = numero;
		this.tipo = tipo;
		this.transporte = transporte;
		this.duracion = duracion;
		this.agencia = agencia;
		this.lugar = lugar;
	}

	public void execute() {
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();
			
			Element rootElement = doc.createElement("ruta");
			doc.appendChild(rootElement);
			Element informacion = doc.createElement("informacion");
			rootElement.appendChild(informacion);
			Element numero = doc.createElement("numero");
			numero.appendChild(doc.createTextNode(this.numero));
			informacion.appendChild(numero);
			Element tipo = doc.createElement("tipo");
			tipo.appendChild(doc.createTextNode(this.tipo));
			informacion.appendChild(tipo);
			Element transporte = doc.createElement("transporte");
			transporte.appendChild(doc.createTextNode(this.transporte));
			informacion.appendChild(transporte);
			Element duracion = doc.createElement("duracion");
			duracion.appendChild(doc.createTextNode(this.duracion));
			informacion.appendChild(duracion);
			Element gestion = doc.createElement("gestion");
			gestion.appendChild(doc.createTextNode(this.agencia));
			informacion.appendChild(gestion);
			Element lugar = doc.createElement("lugar");
			lugar.appendChild(doc.createTextNode(this.lugar));
			informacion.appendChild(lugar);

			TransformerFactory transformador = TransformerFactory.newInstance();
			Transformer transformer = transformador.newTransformer();
			
			File home = FileSystemView.getFileSystemView().getHomeDirectory();
			StringBuilder homeD = new StringBuilder();
			homeD.append(home.getAbsolutePath());
			homeD.append("�ile" + this.numero +".xml");
			String path = homeD.toString().replace("�" , "\\f");
			
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(path));
			transformer.transform(source, result);
			
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		}
	}
}
